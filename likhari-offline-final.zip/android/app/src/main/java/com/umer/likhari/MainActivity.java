package com.umer.likhari;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
