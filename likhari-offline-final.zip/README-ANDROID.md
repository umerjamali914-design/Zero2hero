# Likhari — 100% Offline Android App

Poori app (145 levels, 401 awaaz files, fonts, music, tasveerein) `www/` aur
`android/app/src/main/assets/public/` ke andar hai. APK internet se kuch nahi kholti.

## APK banana (Android Studio — computer par)
1. Android Studio install karo, `android/` folder kholo.
2. Build → Build APK(s). APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## Bina computer ke (GitHub, free)
Ye folder GitHub repo main upload karo → Actions → "Build APK" → Artifacts se APK download.

## Source se dobara banana
`source/` folder main: `bun install && bun run build:android`, phir
`dist/client` ko yahan `www/` main copy karo aur `npx cap sync android`.
