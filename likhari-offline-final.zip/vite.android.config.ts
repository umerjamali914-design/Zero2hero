// Static build for the Android (Capacitor) app: every file is bundled inside the APK.
// Run: bun run build:android  → output in dist-android/
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    server: { entry: "server" },
    spa: { enabled: true, prerender: { outputPath: "/index.html", crawlLinks: false } },
  },
});
